
package domain;

public class Administrator extends Endorser {

}
