package repositories;


public interface AdministratorRepository {

}
