package services;


import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.ActorRepository;
import domain.Actor;
import domain.Customer;
import domain.FixUpTask;
import domain.MessageBox;

@Service
@Transactional
public class ActorService {

	@Autowired
	private ActorRepository	actorRepository;


	public Actor create() {
		return new Actor();
	}
	public Collection<Actor> findAll() {
		return this.actorRepository.findAll();
	}
	public Actor findOne(final int actorId) {
		return this.actorRepository.findOne(actorId);
	}
	public Actor save(final Actor actor) {
		return this.actorRepository.save(actor);
	}
	public void delete(final Actor actor) {
		this.actorRepository.delete(actor);
	}
	
	
	@Autowired
	private MessageBoxService		mbs;
	public MessageBox createNewMessageBox(final String username, final String msgboxname) {
		final MessageBox msgbox = this.mbs.create();
		msgbox.setName(username + " " + msgboxname);
		msgbox.setSystemBox(true);

		final MessageBox result = this.mbs.save(msgbox);

		return result;
	}
	
/*public Actor editData(Actor a1,String username,String password){

		Assert.notNull(a1);
		Assert.notNull(username);
		Assert.notNull(password);
		
	     final Actor a2 = create();
		a2.setAddress(a1.getAddress());
		a2.setEmail(a1.getEmail());
		a2.setMiddleName(a1.getMiddleName());
		a2.setName(a1.getName());
		a2.setPhone(a1.getPhone());
		a2.setPhoto(a1.getPhoto());
		a2.setProfiles(new ArrayList<Profile>());
		a2.setIsSuspicious(a1.getIsSuspicious());
		a2.setIsBanned(a1.getIsBanned());
		
		final MessageBox in = this.createNewMessageBox(username, "-in");
		final MessageBox out = this.createNewMessageBox(username, "-out");
		final MessageBox trash = this.createNewMessageBox(username, "-trash");
		final MessageBox spam = this.createNewMessageBox(username, "-spam");

		final Collection<MessageBox> msboxes = new ArrayList<MessageBox>();
		msboxes.add(in);
		msboxes.add(out);
		msboxes.add(trash);
		msboxes.add(spam);

		a2.setMessageBoxes(msboxes);
		final Actor x= this.save(a2);

	 
		 return x;
		
	
}
*/
}
