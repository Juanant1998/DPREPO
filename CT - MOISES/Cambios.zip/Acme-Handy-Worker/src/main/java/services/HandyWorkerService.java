
package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.HandyWorkerRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;
import domain.HandyWorker;

@Service
@Transactional
public class HandyWorkerService {

	@Autowired
	private HandyWorkerRepository	handyWorkerRepository;


	public HandyWorker create() {
		return new HandyWorker();
	}
	public Collection<HandyWorker> findAll() {
		return this.handyWorkerRepository.findAll();
	}
	public HandyWorker findOne(final int handyWorkerId) {
		return this.handyWorkerRepository.findOne(handyWorkerId);
	}
	public HandyWorker save(final HandyWorker handyWorker) {
		return this.handyWorkerRepository.save(handyWorker);
	}
	public void delete(final HandyWorker handyWorker) {
		this.handyWorkerRepository.delete(handyWorker);
	}
	public void checkAuthority(){
		UserAccount  user;
		user = LoginService.getPrincipal();
		Assert.notNull(user);
		Collection<Authority> authority =user.getAuthorities();
		Assert.notNull(authority);
		Authority a1 = new Authority();
		a1.setAuthority(Authority.HANDYWORKER);
		Assert.isTrue(authority.contains(a1));
	}
}
