package services;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.CustomerRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;

import domain.Customer;
import domain.FixUpTask;
import domain.MessageBox;

@Service
@Transactional

public class CustomerService {

	@Autowired
	private CustomerRepository customerRepository; 
	
	public Customer create(){
		return new Customer();
	}
	public Collection<Customer> findAll(){
		return customerRepository.findAll();
	}
	public Customer findOne(int customerId){
		return customerRepository.findOne(customerId);
	}
	public Customer save(Customer customer){
		return customerRepository.save(customer);
	}
	public void delete(Customer customer){
		customerRepository.delete(customer);
	}
	public void checkAuthority(){
	
			UserAccount  user;
			user = LoginService.getPrincipal();
			Assert.notNull(user);
			Collection<Authority> authority =user.getAuthorities();
			Assert.notNull(authority);
			Authority a1 = new Authority();
			a1.setAuthority(Authority.CUSTOMER);
			Assert.isTrue(authority.contains(a1));
		
	}
	@Autowired
	private MessageBoxService		mbs;
	public MessageBox createNewMessageBox(final String username, final String msgboxname) {
		final MessageBox msgbox = this.mbs.create();
		msgbox.setName(username + " " + msgboxname);
		msgbox.setSystemBox(true);

		final MessageBox result = this.mbs.save(msgbox);

		return result;
	}
	
	
	public Customer register(final Customer c1,final String username,final String password){
		Assert.notNull(c1);
		Assert.notNull(username);
		Assert.notNull(password);
		checkAuthority();
	
		final Customer c2 = create();
		c2.setAddress(c1.getAddress());
		c2.setEmail(c1.getEmail());
		c2.setFixUpTasks(new ArrayList<FixUpTask>());
		c2.setMiddleName(c1.getMiddleName());
		c2.setName(c1.getName());
		c2.setPhone(c1.getPhone());
		c2.setPhoto(c1.getPhoto());
		c2.setIsSuspicious(c1.getIsSuspicious());
		c2.setIsBanned(c1.getIsBanned());
		 
			final MessageBox in = this.createNewMessageBox(username, "-in");
			final MessageBox out = this.createNewMessageBox(username, "-out");
			final MessageBox trash = this.createNewMessageBox(username, "-trash");
			final MessageBox spam = this.createNewMessageBox(username, "-spam");

			final Collection<MessageBox> msboxes = new ArrayList<MessageBox>();
			msboxes.add(in);
			msboxes.add(out);
			msboxes.add(trash);
			msboxes.add(spam);

			c2.setMessageBoxes(msboxes);
			final Customer x= this.save(c2);

		 
			 return x;
		 
		
	}
}
