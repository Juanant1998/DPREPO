package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Administrator;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
		"classpath:spring/dataSource.xml",
		"classpath:spring/config/packages.xml"
	})


@Transactional
public class AdministratorServiceTest extends AbstractTest {

	
	@Autowired
	private AdministratorService administratorService;
	
	@Test
	public void testSaveAdministrators(){
		Administrator saved = this.administratorService.findOne(super.getEntityId("administrator1"));
		Collection<Administrator> administrators = new ArrayList<>();
		
		this.administratorService.save(saved);
		administrators.add(saved);
		
		Assert.isTrue(administrators.contains(saved));
		
	}
	@Test
	public void deleteTest(){
		Administrator saved = this.administratorService.findOne(super.getEntityId("administrator1"));
		
		this.administratorService.delete(saved);
		Assert.isNull(this.administratorService.findOne(saved.getId()));
	}

	@Test
	public void testFindAll() {
		Collection<Administrator> administrators;
		administrators = this.administratorService.findAll();
		Assert.isTrue(!administrators.isEmpty());
	}
	
	@Test
	public void testFindOne(){
		Administrator a;
		a = this.administratorService.findOne(super.getEntityId("administrator2"));
		int findId = a.getId();
		Assert.notNull(this.administratorService.findOne(findId));
		
	}

	@Test
	public void testCreate(){
		Administrator a = this.administratorService.create();
		Assert.notNull(a);
	}

}