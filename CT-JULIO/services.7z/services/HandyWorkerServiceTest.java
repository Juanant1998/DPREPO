
package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Actor;
import domain.HandyWorker;

import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class HandyWorkerServiceTest extends AbstractTest {

	@Autowired
	private HandyWorkerService handyWorkerService;
	

	@Test 
	public void testSaveActors(){
		//Actor
		Collection<HandyWorker> actors = new ArrayList<>();
		HandyWorker guardando=handyWorkerService.findOne(super.getEntityId("handyWorker3"));
		handyWorkerService.save(guardando);
		actors.add(guardando);
		Assert.isTrue(actors.contains(guardando));
		
	}
	@Test
	public void  testDeleteHandy(){
		HandyWorker borrando= handyWorkerService.findOne(super.getEntityId("handyWorker3"));
			handyWorkerService.delete(borrando);
			Assert.isNull(handyWorkerService.findOne(borrando.getId()));
	}
	@Test
	public void  findOneOk(){
		HandyWorker  find = handyWorkerService.findOne(super.getEntityId("handyWorker3"));
		 int  findId= find.getId();
		 Assert.notNull(handyWorkerService.findOne(findId));
	}
	@Test
	public void FindAll(){
		Collection<HandyWorker> actors;
		actors = this.handyWorkerService.findAll();
		Assert.isTrue(!actors.isEmpty());
		
	}
	@Test
	public void CreateTest(){
		HandyWorker  create= handyWorkerService.create();
		Assert.notNull(create);
		
	}
}
