package services;

import java.util.ArrayList;
import java.util.Collection;



import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Actor;
import domain.Message;
import domain.MessageBox;
import domain.Profile;

import security.Authority;
import security.UserAccount;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})

@Transactional
public class ActorServiceTest extends AbstractTest  {
@Autowired
private ActorService actorService;

@Test 
public void testSaveActors(){
	//Actor
	Collection<Actor> actors = new ArrayList<>();
	Actor guardando=actorService.findOne(super.getEntityId("handyWorker3"));
	actorService.save(guardando);
	actors.add(guardando);
	Assert.isTrue(actors.contains(guardando));
	
}
@Test
public void  testDeleteActor(){
	Actor borrando= actorService.findOne(super.getEntityId("handyWorker3"));
		actorService.delete(borrando);
		Assert.isNull(actorService.findOne(borrando.getId()));
}
@Test
public void  findOneOk(){
	 Actor  find = actorService.findOne(super.getEntityId("handyWorker3"));
	 int  findId= find.getId();
	 Assert.notNull(actorService.findOne(findId));
}
@Test
public void FindAll(){
	Collection<Actor> actors;
	actors = this.actorService.findAll();
	Assert.isTrue(!actors.isEmpty());
	
}
@Test
public void CreateTest(){
	Actor  create= actorService.create();
	Assert.notNull(create);
	
}
}
