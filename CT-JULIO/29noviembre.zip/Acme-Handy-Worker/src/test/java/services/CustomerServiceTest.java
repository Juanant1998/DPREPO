package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Customer;


import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
		"classpath:spring/dataSource.xml",
		"classpath:spring/config/packages.xml"
	})


@Transactional
public class CustomerServiceTest extends AbstractTest {
	@Autowired
	private CustomerService customerService;
	
	@Test
	public void testSaveCustomers(){
		Customer saved = this.customerService.findOne(super.getEntityId("customer1"));
		Collection<Customer> customers = new ArrayList<>();
		
		this.customerService.save(saved);
		customers.add(saved);
		
		Assert.isTrue(customers.contains(saved));
		
	}
	@Test
	public void deleteTest(){
		Customer saved = this.customerService.findOne(super.getEntityId("customer1"));
		
		this.customerService.delete(saved);
		Assert.isNull(this.customerService.findOne(saved.getId()));
	}

	@Test
	public void testFindAll() {
		Collection<Customer> customers;
		customers = this.customerService.findAll();
		Assert.isTrue(!customers.isEmpty());
	}
	
	@Test
	public void testFindOne(){
		Customer c;
		c = this.customerService.findOne(super.getEntityId("customer2"));
		int findId = c.getId();
		Assert.notNull(this.customerService.findOne(findId));
		
	}

	@Test
	public void testCreate(){
		Customer c = this.customerService.create();
		Assert.notNull(c);
	}

}

